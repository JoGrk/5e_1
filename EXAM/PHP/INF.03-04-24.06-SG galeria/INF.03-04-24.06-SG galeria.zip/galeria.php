<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeria</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header><h1>Zdjęcia</h1></header>
    <section class = "left">
        <h2>Tematy zdjęć</h2>
        <ol>
            <li>Zwierzęta</li>
            <li>Krajobrazy</li>
            <li>Miasta</li>
            <li>Przyroda</li>
            <li>Samochody</li>
        </ol>
    </section>
    <section class = "center">
        <!-- script1 -->
    </section>
    <section class = "right">
        <h2>Najbardziej lubiane</h2>
        <!-- script2 -->
        <p><strong>Zobacz wszystkie nasze zdjęcia</strong></p>
    </section>
    <footer>
        <h5>Strone wykonał: XXX</h5>
    </footer>
</body>
</html>